Dataset by James William Fletcher (github.com/mrbid)
Downloaded from: https://github.com/TFCNN/DOCS/tree/main/DATASETS
