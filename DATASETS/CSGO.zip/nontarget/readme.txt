Dataset by James William Fletcher (github.com/mrbid)
Downloaded from: https://github.com/TFNN/DOCS/tree/main/DATASETS
