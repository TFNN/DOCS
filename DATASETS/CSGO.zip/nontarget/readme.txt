Dataset by James William Fletcher (james@voxdsp.com)
https://github.com/mrbid
